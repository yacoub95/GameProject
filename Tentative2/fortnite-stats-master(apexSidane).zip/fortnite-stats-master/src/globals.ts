export const GlobalVar = Object.freeze({

    FORTNITE_API: 'ea402410-8663-41ff-9997-7e94a78d8d62'

});