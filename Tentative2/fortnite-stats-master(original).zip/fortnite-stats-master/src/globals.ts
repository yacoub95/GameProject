export const GlobalVar = Object.freeze({

    FORTNITE_API: '02021ada-2359-4fbc-b32d-7d5d368c4018'

});